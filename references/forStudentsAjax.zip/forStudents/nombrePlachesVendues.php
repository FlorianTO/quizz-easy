<?php
// Commence avec un nombre al�atoire de planches vendues
srand((double)microtime() * 1000000);
header('Content-Type: application/xml; charset=utf-8');

?>

<totaux>

<?php if (strcmp("lacanau", $_GET["nom"])===0 or strcmp("toutes", $_GET["nom"])===0): ?>  
  <lacanau> <?php echo rand(0,1000) ?> </lacanau>  
<?php endif ?>

<?php if (strcmp("biarritz", $_GET["nom"])===0 or strcmp("toutes", $_GET["nom"])===0): ?>  
  <biarritz> <?php echo rand(0,1000) ?> </biarritz>  
<?php endif ?>

<?php if (strcmp("nice", $_GET["nom"])===0 or strcmp("toutes", $_GET["nom"])===0): ?>  
  <nice> <?php echo rand(0,1000) ?> </nice>  
<?php endif ?>


</totaux>







